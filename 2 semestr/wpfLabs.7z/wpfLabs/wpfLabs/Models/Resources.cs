﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace wpfLabs.Models
{
    public static class Resources
    {
        public static readonly Dictionary<string, ResourceDictionary> Languages = new Dictionary<string, ResourceDictionary>
        {
            {"Russian/Русский", new ResourceDictionary(){ Source=new Uri("../../Resources/lang.ru-RU.xaml", UriKind.Relative)} },
            {"English/Английский", new ResourceDictionary(){ Source=new Uri("../../Resources/lang.en-US.xaml", UriKind.Relative)} },
        };

    }
}

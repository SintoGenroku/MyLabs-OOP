﻿using System.Windows.Controls;

namespace wpfLabs
{
    /// <summary>
    /// Логика взаимодействия для temp.xaml
    /// </summary>
    public partial class temp : Page
    {
        public temp()
        {
            InitializeComponent();
        }



    }
}
